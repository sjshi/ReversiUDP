#!/usr/bin/env python
import pygame, sys, random  
from pygame.locals import * 
from socket import *
serverName = '127.0.0.1'
serverPort = 12000
clientSocket = socket(AF_INET, SOCK_DGRAM)

BACKGROUNDCOLOR = (255, 255, 255)  
BLACK = (255, 255, 255)  
BLUE = (0, 0, 255)  
CELLWIDTH = 48  
CELLHEIGHT = 48  
PIECEWIDTH = 48  
PIECEHEIGHT = 48  
BOARDX = 32  
BOARDY = 32  
FPS = 40  


while True:
    print("欢迎使用石胜娇的黑白棋，祝您游戏愉快!")
    username = input("请输入您的用户名（5个字母或数字，不能有空格）：")
    if len(username) == 5:
        break
    else:
        print("输入错误，请重新输入！")
message = "login" + username
clientSocket.sendto(('%s\r' % message).encode(), (serverName, serverPort))



pygame.init()#初始化pygame,为使用硬件做准备 
screen = pygame.display.set_mode((990,448), 0, 32)#创建了一个窗口
pygame.display.set_caption("黑白棋大厅")
#加载图片
background_image_filename = 'res/background.png'
background = pygame.image.load(background_image_filename).convert()

#第一排
board00_image_filename = 'res/Frame1-1.bmp'
board01_image_filename = 'res/Frame1-2.bmp'
board02_image_filename = 'res/Frame1-3.bmp'
board03_image_filename = 'res/Frame1-4.bmp'
board04_image_filename = 'res/Frame1-5.bmp'
board05_image_filename = 'res/Frame1-6.bmp'
board06_image_filename = 'res/Frame1-7.bmp'
board07_image_filename = 'res/Frame1-8.bmp'
board08_image_filename = 'res/Frame1-9.bmp'
board09_image_filename = 'res/Frame1-10.bmp'

board00 = pygame.image.load(board00_image_filename).convert()
board01 = pygame.image.load(board01_image_filename).convert()
board02 = pygame.image.load(board02_image_filename).convert()
board03 = pygame.image.load(board03_image_filename).convert()
board04 = pygame.image.load(board04_image_filename).convert()
board05 = pygame.image.load(board05_image_filename).convert()
board06 = pygame.image.load(board06_image_filename).convert()
board07 = pygame.image.load(board07_image_filename).convert()
board08 = pygame.image.load(board08_image_filename).convert()
board09 = pygame.image.load(board09_image_filename).convert()
#最后一排
board90_image_filename = 'res/Frame10-1.bmp'
board91_image_filename = 'res/Frame10-2.bmp'
board92_image_filename = 'res/Frame10-3.bmp'
board93_image_filename = 'res/Frame10-4.bmp'
board94_image_filename = 'res/Frame10-5.bmp'
board95_image_filename = 'res/Frame10-6.bmp'
board96_image_filename = 'res/Frame10-7.bmp'
board97_image_filename = 'res/Frame10-8.bmp'
board98_image_filename = 'res/Frame10-9.bmp'
board99_image_filename = 'res/Frame10-10.bmp'

board90 = pygame.image.load(board90_image_filename).convert()
board91 = pygame.image.load(board91_image_filename).convert()
board92 = pygame.image.load(board92_image_filename).convert()
board93 = pygame.image.load(board93_image_filename).convert()
board94 = pygame.image.load(board94_image_filename).convert()
board95 = pygame.image.load(board95_image_filename).convert()
board96 = pygame.image.load(board96_image_filename).convert()
board97 = pygame.image.load(board97_image_filename).convert()
board98 = pygame.image.load(board97_image_filename).convert()
board99 = pygame.image.load(board99_image_filename).convert()

#第一列除第一排和最后一排
board10_image_filename = 'res/Frame2-1.bmp'
board20_image_filename = 'res/Frame3-1.bmp'
board30_image_filename = 'res/Frame4-1.bmp'
board40_image_filename = 'res/Frame5-1.bmp'
board50_image_filename = 'res/Frame6-1.bmp'
board60_image_filename = 'res/Frame7-1.bmp'
board70_image_filename = 'res/Frame8-1.bmp'
board80_image_filename = 'res/Frame9-1.bmp'
board10 = pygame.image.load(board10_image_filename).convert()
board20 = pygame.image.load(board20_image_filename).convert()
board30 = pygame.image.load(board30_image_filename).convert()
board40 = pygame.image.load(board40_image_filename).convert()
board50 = pygame.image.load(board50_image_filename).convert()
board60 = pygame.image.load(board60_image_filename).convert()
board70 = pygame.image.load(board70_image_filename).convert()
board80 = pygame.image.load(board80_image_filename).convert()

#最后一列除第一排和最后一排
board19_image_filename = 'res/Frame2-10.bmp'
board29_image_filename = 'res/Frame3-10.bmp'
board39_image_filename = 'res/Frame4-10.bmp'
board49_image_filename = 'res/Frame5-10.bmp'
board59_image_filename = 'res/Frame6-10.bmp'
board69_image_filename = 'res/Frame7-10.bmp'
board79_image_filename = 'res/Frame8-10.bmp'
board89_image_filename = 'res/Frame9-10.bmp'

board19 = pygame.image.load(board19_image_filename).convert()
board29 = pygame.image.load(board29_image_filename).convert()
board39 = pygame.image.load(board39_image_filename).convert()
board49 = pygame.image.load(board49_image_filename).convert()
board59 = pygame.image.load(board59_image_filename).convert()
board69 = pygame.image.load(board69_image_filename).convert()
board79 = pygame.image.load(board79_image_filename).convert()
board89 = pygame.image.load(board89_image_filename).convert()

white_image_filename = 'res/white.bmp'
white = pygame.image.load(white_image_filename).convert()
black_image_filename = 'res/black.bmp'
black = pygame.image.load(black_image_filename).convert()
empty_image_filename = 'res/Empty.bmp'
empty = pygame.image.load(empty_image_filename).convert()
room_image_filename = 'res/room.png'
roompng = pygame.image.load(room_image_filename).convert()
danji_image_filename = 'res/danji.png'
danji = pygame.image.load(danji_image_filename).convert()
font = pygame.font.SysFont("arial", 16);


userlist = []
usernumber = 0

#定义房间类
class room:
    blackclient = 'noone'
    whiteclient = 'noone'
    def _init_ (self):#初始化
        self.blackclient = 'noone'
        self.whiteclient = 'noone'
    def set_blackclient(self,blackclient):
        self.blackclient = blackclient
    def set_whiteclient(self,whiteclient):
        self.whiteclient = whiteclient


#创建10个房间
room0 = room()
room1 = room()
room2 = room()
room3 = room()
room4 = room()
room5 = room()
room6 = room()
room7 = room()
room8 = room()
room9 = room()

#打印所有房间
def print_room(room0,room1,room3,room4,room5,room6,room7,room8,room9):
    screen.blit(danji, (890, 10))
    for i in range(0,2):
        for j in range(0,5):
            screen.blit(roompng, (j * 170 + 10, i * 200 +40))
            if (i*5+j ) == 0:
                temp = "room:1"
                screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 55, i * 200 +50) )
                if room0.blackclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                else:
                    temp = room0.blackclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                if room0.whiteclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
                else:
                    temp = room0.whiteclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
            if (i*5+j) == 1:
                temp = "room:2"
                screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 55, i * 200 +50) )
                if room1.blackclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                else:
                    temp = room1.blackclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                if room1.whiteclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
                else:
                    temp = room1.whiteclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
            if (i*5+j) == 2:
                temp = "room:3"
                screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 55, i * 200 +50) )
                if room2.blackclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                else:
                    temp = room2.blackclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                if room2.whiteclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
                else:
                    temp = room2.whiteclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
            if (i*5+j) == 3:
                temp = "room:4"
                screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 55, i * 200 +50) )
                if room3.blackclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                else:
                    temp = room3.blackclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                if room3.whiteclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
                else:
                    temp = room3.whiteclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
            if (i*5+j) == 4:
                temp = "room:5"
                screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 55, i * 200 +50) )
                if room4.blackclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                else:
                    temp = room4.blackclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                if room4.whiteclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
                else:
                    temp = room4.whiteclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
            if (i*5+j) == 5:
                temp = "room:6"
                screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 55, i * 200 +50) )
                if room5.blackclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                else:
                    temp = room5.blackclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                if room5.whiteclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
                else:
                    temp = room5.whiteclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
            if (i*5+j) == 6:
                temp = "room:7"
                screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 55, i * 200 +50) )
                if room6.blackclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                else:
                    temp = room6.blackclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                if room6.whiteclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
                else:
                    temp = room6.whiteclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
            if (i*5+j) == 7:
                temp = "room:8"
                screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 55, i * 200 +50) )
                if room7.blackclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                else:
                    temp = room7.blackclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                if room7.whiteclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
                else:
                    temp = room7.whiteclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
            if (i*5+j) == 8:
                temp = "room:9"
                screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 55, i * 200 +50) )
                if room8.blackclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                else:
                    temp = room8.blackclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                if room8.whiteclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
                else:
                    temp = room8.whiteclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
            if (i*5+j) == 9:
                temp = "room:10"
                screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 55, i * 200 +50) )
                if room9.blackclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                else:
                    temp = room9.blackclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 28, i * 200 +175) )
                if room9.whiteclient == 'noone':
                    screen.blit( font.render("no one", True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )
                else:
                    temp = room9.whiteclient
                    screen.blit( font.render(temp, True, (0, 0, 0)), (j * 170 + 85, i * 200 +175) )


#打印所有用户
def print_user(userlist,usernumber):
    temp = "user:" + str(usernumber)
    screen.blit( font.render(temp, True, (0, 0, 0)), (885, 20) )
    for i in range(usernumber):
        temp = userlist[i]
        screen.blit( font.render(temp, True, (0, 0, 0)), (885, i *20 +40) )

#获取房间信息
def get_room(room0,room1,room3,room4,room5,room6,room7,room8,room9):
    message = "getro"
    clientSocket.sendto(('%s\r' % message).encode(), (serverName, serverPort))
    modifimessage, serverAddress = clientSocket.recvfrom(2048)
    for i in range(0,10):
        if i == 0:
            room0.blackclient = modifimessage[i*15+5:i*15+10]
            room0.whiteclient = modifimessage[i*15+10:i*15+15]
        if i == 1:
            room1.blackclient = modifimessage[i*15+5:i*15+10]
            room1.whiteclient = modifimessage[i*15+10:i*15+15]
        if i == 2:
            room2.blackclient = modifimessage[i*15+5:i*15+10]
            room2.whiteclient = modifimessage[i*15+10:i*15+15]
        if i == 3:
            room3.blackclient = modifimessage[i*15+5:i*15+10]
            room3.whiteclient = modifimessage[i*15+10:i*15+15]
        if i == 4:
            room4.blackclient = modifimessage[i*15+5:i*15+10]
            room4.whiteclient = modifimessage[i*15+10:i*15+15]
        if i == 5:
            room5.blackclient = modifimessage[i*15+5:i*15+10]
            room5.whiteclient = modifimessage[i*15+10:i*15+15]
        if i == 6:
            room6.blackclient = modifimessage[i*15+5:i*15+10]
            room6.whiteclient = modifimessage[i*15+10:i*15+15]
        if i == 7:
            room7.blackclient = modifimessage[i*15+5:i*15+10]
            room7.whiteclient = modifimessage[i*15+10:i*15+15]
        if i == 8:
            room8.blackclient = modifimessage[i*15+5:i*15+10]
            room8.whiteclient = modifimessage[i*15+10:i*15+15]
        if i == 9:
            room9.blackclient = modifimessage[i*15+5:i*15+10]
            room9.whiteclient = modifimessage[i*15+10:i*15+15]
        
#获取所有玩家
def get_user(userlist,usernumber):
    message = "getus"
    clientSocket.sendto(('%s\r' % message).encode(), (serverName, serverPort))
    modifimessage, serverAddress = clientSocket.recvfrom(2048)
    temp = modifimessage.decode('utf-8')
    i = 0
    userlist = []
    print(temp)
    while len(temp) > (i*10+1):
        userlist.append(temp[i*10+5:i*10+10])
        usernumber = usernumber + 1
        #print(userlist[i])
        i = i + 1

    
        

#打印棋盘
def print_board(board,turn):
    screen.blit(board00, (0,0))
    screen.blit(board01, (32,0))
    screen.blit(board02, (80,0))
    screen.blit(board03, (128,0))
    screen.blit(board04, (176,0))
    screen.blit(board05, (224,0))
    screen.blit(board06, (272,0))
    screen.blit(board07, (320,0))
    screen.blit(board08, (368,0))
    screen.blit(board09, (416,0))

    screen.blit(board90, (0,416))
    screen.blit(board91, (32,416))
    screen.blit(board92, (80,416))
    screen.blit(board93, (128,416))
    screen.blit(board94, (176,416))
    screen.blit(board95, (224,416))
    screen.blit(board96, (272,416))
    screen.blit(board97, (320,416))
    screen.blit(board98, (368,416))
    screen.blit(board99, (416,416))

    screen.blit(board10, (0,32))
    screen.blit(board20, (0,80))
    screen.blit(board30, (0,128))
    screen.blit(board40, (0,176))
    screen.blit(board50, (0,224))
    screen.blit(board60, (0,272))
    screen.blit(board70, (0,320))
    screen.blit(board80, (0,368))

    screen.blit(board19, (416,32))
    screen.blit(board29, (416,80))
    screen.blit(board39, (416,128))
    screen.blit(board49, (416,176))
    screen.blit(board59, (416,224))
    screen.blit(board69, (416,272))
    screen.blit(board79, (416,320))
    screen.blit(board89, (416,368))

    for i in range(0,8):
        for j in range(0,8):
            if board[i][j] == 'white':
                screen.blit(white, (32+i*48,32+j*48))
            elif board[i][j] == 'black':
                screen.blit(black, (32+i*48,32+j*48))
            else:
                screen.blit(empty, (32+i*48,32+j*48))
    scoreblack = str(getScoreOfBoard(board)['black'])  
    scorewhite = str(getScoreOfBoard(board)['white'])
    temp = "BLACK:" + scoreblack + "      WHITE:" + scorewhite
    font = pygame.font.SysFont("arial", 16);
    screen.blit( font.render(temp, True, (255, 255, 255)), (500, 50) )
    if turn == "black" or turn == "waitb":
        screen.blit( font.render("You are black!", True, (255, 255, 255)), (500, 80) )
    else:
        screen.blit( font.render("You are white!", True, (255, 255, 255)), (500, 80) )
    if turn[0:4] =="wait":
        screen.blit( font.render("Please waiting!", True, (255, 255, 255)), (500, 100) )
    else:
        screen.blit( font.render("It is your turn!", True, (255, 255, 255)), (500, 100) )
    
# 退出  
def terminate(): 
    pygame.quit()
    sys.exit()            

#重置棋盘
def resetBoard(board):  
    for x in range(8):  
        for y in range(8):  
            board[x][y] = 'none'  
    # Starting pieces:  
    board[3][3] = 'black'  
    board[3][4] = 'white'  
    board[4][3] = 'white'  
    board[4][4] = 'black' 
 
# 开局时建立新棋盘  
def getNewBoard():  
    board = []  
    for i in range(8):  
        board.append(['none'] * 8)  
  
    return board  

# 是否是合法走法  
def isValidMove(board, tile, xstart, ystart):  
    # 如果该位置已经有棋子或者出界了，返回False  
    if not isOnBoard(xstart, ystart) or board[xstart][ystart] != 'none':  
        return False  
  
    # 临时将tile 放到指定的位置  
    board[xstart][ystart] = tile  
  
    if tile == 'black':  
        otherTile = 'white'  
    else:  
        otherTile = 'black'  
  
    # 要被翻转的棋子  
    tilesToFlip = []  
    for xdirection, ydirection in [ [0, 1], [1, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1] ]:  
        x, y = xstart, ystart  
        x += xdirection  
        y += ydirection  
        if isOnBoard(x, y) and board[x][y] == otherTile:  
            x += xdirection  
            y += ydirection  
            if not isOnBoard(x, y):  
                continue  
            # 一直走到出界或不是对方棋子的位置  
            while board[x][y] == otherTile:  
                x += xdirection  
                y += ydirection  
                if not isOnBoard(x, y):  
                    break  
            # 出界了，则没有棋子要翻转OXXXXX  
            if not isOnBoard(x, y):  
                continue  
            # 是自己的棋子OXXXXXXO  
            if board[x][y] == tile:  
                while True:  
                    x -= xdirection  
                    y -= ydirection  
                    # 回到了起点则结束  
                    if x == xstart and y == ystart:  
                        break  
                    # 需要翻转的棋子  
                    tilesToFlip.append([x, y])  
  
    # 将前面临时放上的棋子去掉，即还原棋盘  
    board[xstart][ystart] = 'none' # restore the empty space  
  
    # 没有要被翻转的棋子，则走法非法。翻转棋的规则。  
    if len(tilesToFlip) == 0:   # If no tiles were flipped, this is not a valid move.  
        return False  
    return tilesToFlip  

# 是否出界  
def isOnBoard(x, y):  
    return x >= 0 and x <= 7 and y >= 0 and y <=7  

# 获取可落子的位置  
def getValidMoves(board, tile):  
    validMoves = []  
  
    for x in range(8):  
        for y in range(8):  
            if isValidMove(board, tile, x, y) != False:  
                validMoves.append([x, y])  
    return validMoves  
  
# 获取棋盘上黑白双方的棋子数  
def getScoreOfBoard(board):  
    xscore = 0  
    oscore = 0  
    for x in range(8):  
        for y in range(8):  
            if board[x][y] == 'black':  
                xscore += 1  
            if board[x][y] == 'white':  
                oscore += 1  
    return {'black':xscore, 'white':oscore}  


#将一个tile棋子放到(xstart, ystart) 
def makeMove(board, tile, xstart, ystart):  
    tilesToFlip = isValidMove(board, tile, xstart, ystart)  
  
    if tilesToFlip == False:  
        return False  
  
    board[xstart][ystart] = tile  
    for x, y in tilesToFlip:  
        board[x][y] = tile  
    return True  
  
# 复制棋盘  
def getBoardCopy(board):  
    dupeBoard = getNewBoard()  
  
    for x in range(8):  
        for y in range(8):  
            dupeBoard[x][y] = board[x][y]  
  
    return dupeBoard  
  
# 是否在角上  
def isOnCorner(x, y):  
    return (x == 0 and y == 0) or (x == 7 and y == 0) or (x == 0 and y == 7) or (x == 7 and y == 7)  

# 电脑走法，AI  
def getwhiteMove(board, whiteTile):  
    # 获取所以合法走法  
    possibleMoves = getValidMoves(board, whiteTile)  
  
    # 打乱所有合法走法  
    random.shuffle(possibleMoves)  
  
    # [x, y]在角上，则优先走，因为角上的不会被再次翻转  
    for x, y in possibleMoves:  
        if isOnCorner(x, y):  
            return [x, y]  
  
    bestScore = -1  
    for x, y in possibleMoves:  
        dupeBoard = getBoardCopy(board)  
        makeMove(dupeBoard, whiteTile, x, y)  
        # 按照分数选择走法，优先选择翻转后分数最多的走法  
        score = getScoreOfBoard(dupeBoard)[whiteTile]  
        if score > bestScore:  
            bestMove = [x, y]  
            bestScore = score  
    return bestMove 

# 是否游戏结束  
def isGameOver(board):  
    for x in range(8):  
        for y in range(8):  
            if board[x][y] == 'none':  
                return False  
    return True  

# 游戏函数
def Game(turn):
    screen = pygame.display.set_mode((990,448), 0, 32)#创建了一个窗口
    pygame.display.set_caption("黑白棋对战")
    mainClock = pygame.time.Clock()    
    basicFont = pygame.font.SysFont(None, 48)  
    gameoverStr = 'Game Over Score '    
    mainBoard = getNewBoard()  
    resetBoard(mainBoard)  
    if turn == "white":
        turn = "waitw"
    blackTile = 'black'  
    whiteTile = 'white'   
    gameOver = False  
    screen.blit(background, (0,0))    #将背景图画上去
    print_board(mainBoard,turn)
    pygame.display.update()#刷新一下画面
    if turn == "waitb":
        modifimessage, serverAddress = clientSocket.recvfrom(2048)
        turn = (modifimessage.decode('utf-8'))
    screen.blit(background, (0,0))    #将背景图画上去
    print_board(mainBoard,turn)
    pygame.display.update()
    while True:#游戏主循环
        for event in pygame.event.get():
            if event.type == QUIT:#接收到退出事件后退出程序
                exit()
            if gameOver == False and turn == 'black' and event.type == MOUSEBUTTONDOWN and event.button == 1:  
                x, y = pygame.mouse.get_pos()  
                col = int((x-BOARDX)/CELLWIDTH)  
                row = int((y-BOARDY)/CELLHEIGHT)  
                if makeMove(mainBoard, blackTile, col, row) == True:  
                    if getValidMoves(mainBoard, whiteTile) != []:
                        temp =((col + 1) * 10 + row + 1 )* -1
                        screen.blit(background, (0,0))    #将背景图画上去
                        turn = "waitb"
                        print_board(mainBoard,turn) 
                        pygame.display.update()#刷新一下画面
                        clientSocket.sendto(('%s\r' % temp).encode(), (serverName, serverPort)) 
            if gameOver == False and turn == 'white' and event.type == MOUSEBUTTONDOWN and event.button == 1:  
                x, y = pygame.mouse.get_pos()  
                col = int((x-BOARDX)/CELLWIDTH)  
                row = int((y-BOARDY)/CELLHEIGHT)  
                if makeMove(mainBoard, whiteTile, col, row) == True:  
                    if getValidMoves(mainBoard, blackTile) != []:                   
                        temp = ((col + 1) * 10 + row + 1)
                        screen.blit(background, (0,0))    #将背景图画上去
                        turn = "waitw"
                        print_board(mainBoard,turn)
                        pygame.display.update()#刷新一下画面
                        clientSocket.sendto(('%s\r' % temp).encode(), (serverName, serverPort)) 
        
        if gameOver == False and turn == "waitb":
            modifimessage, serverAddress = clientSocket.recvfrom(2048)
            temp = int(modifimessage.decode('utf-8'))
            if temp > 0:
                col = int(temp / 10 - 1)
                row = temp % 10 - 1
                if makeMove(mainBoard, whiteTile, col, row) == True:  
                    if getValidMoves(mainBoard, blackTile) != []: 
                        screen.blit(background, (0,0))    #将背景图画上去
                        turn = "black"
                        print_board(mainBoard,turn)
                        pygame.display.update()#刷新一下画面
        if gameOver == False and turn == "waitw":
            modifimessage, serverAddress = clientSocket.recvfrom(2048)
            temp = int(modifimessage.decode('utf-8'))
            if temp < 0:
                temp = temp * -1
                col = int(temp / 10 - 1)
                row = temp % 10 - 1
                if makeMove(mainBoard, blackTile, col, row) == True:  
                    if getValidMoves(mainBoard, whiteTile) != []:
                        screen.blit(background, (0,0))    #将背景图画上去
                        turn = "white"
                        print_board(mainBoard,turn)
                        pygame.display.update()#刷新一下画面
        if isGameOver(mainBoard):
            outputStr = gameoverStr + str(scoreblack) + ":" + str(scorewhite)  
            text = basicFont.render(outputStr, True, BLACK, BLUE)  
            textRect = text.get_rect()  
            textRect.centerx = windowSurface.get_rect().centerx  
            textRect.centery = windowSurface.get_rect().centery  
            windowSurface.blit(text, textRect)  
        pygame.display.update()#刷新一下画面
        mainClock.tick(FPS)  

def danjiGame():
    screen = pygame.display.set_mode((990,448), 0, 32)#创建了一个窗口
    pygame.display.set_caption("黑白棋——人机对战")
    mainClock = pygame.time.Clock()    
    basicFont = pygame.font.SysFont(None, 48)  
    gameoverStr = 'Game Over Score '    
    mainBoard = getNewBoard()  
    resetBoard(mainBoard)    
    turn = 'black'
    blackTile = 'black'  
    whiteTile = 'white' 
    screen.blit(background, (0,0))    #将背景图画上去
    print_board(mainBoard,turn)
    pygame.display.update()
    gameOver = False  
    while True:#游戏主循环
        for event in pygame.event.get():
            if event.type == QUIT:
                exit()
            if gameOver == False and turn == 'black' and event.type == MOUSEBUTTONDOWN and event.button == 1: 
                x, y = pygame.mouse.get_pos()
                col = int((x-BOARDX)/CELLWIDTH)
                row = int((y-BOARDY)/CELLHEIGHT) 
                if makeMove(mainBoard, blackTile, col, row) == True:  
                    if getValidMoves(mainBoard, whiteTile) != []: 
                        turn = 'waitb'  
                        screen.blit(background, (0,0))    #将背景图画上去
                        print_board(mainBoard,turn)
                        pygame.display.update()
        if gameOver == False and turn == 'waitb': 
            x, y = getwhiteMove(mainBoard, whiteTile)
            makeMove(mainBoard, whiteTile, x, y) 
            savex, savey = x, y 
            if getValidMoves(mainBoard, blackTile) != []:
                turn = 'black'
        screen.blit(background, (0,0))    #将背景图画上去
        print_board(mainBoard,turn)
        pygame.display.update()
        if isGameOver(mainBoard):
            outputStr = gameoverStr + str(scoreblack) + ":" + str(scorewhite)  
            text = basicFont.render(outputStr, True, BLACK, BLUE)
            textRect = text.get_rect() 
            textRect.centerx = windowSurface.get_rect().centerx
            textRect.centery = windowSurface.get_rect().centery
            windowSurface.blit(text, textRect)  
            pygame.display.update()#刷新一下画面
            mainClock.tick(FPS)

def Hall(): 
    
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:#接收到退出事件后退出程序
                exit() 
            if event.type == MOUSEBUTTONDOWN and event.button == 1: 
                x, y = pygame.mouse.get_pos()
                if x > 890 and x < 990 and y > 10 and y < 48:
                    danjiGame()               
                elif x < 890 and x >10 and y > 40 and y <440:
                    x, y = pygame.mouse.get_pos()
                    col = int((x-10)/170) 
                    row = int((y-40)/200)
                    temp = str(row * 5 + col)
                    message = "joinroom" + temp + username
                    clientSocket.sendto(('%s\r' % message).encode(), (serverName, serverPort))
                    modifimessage, serverAddress = clientSocket.recvfrom(2048)
                    turn = (modifimessage.decode('utf-8'))
                    Game(turn)
        screen.fill((255, 255, 255))
        get_room(room0,room1,room3,room4,room5,room6,room7,room8,room9)
        print_room(room0,room1,room3,room4,room5,room6,room7,room8,room9)
        #get_user(userlist,usernumber)
        #print_user(userlist,usernumber)
        pygame.display.update()


Hall()