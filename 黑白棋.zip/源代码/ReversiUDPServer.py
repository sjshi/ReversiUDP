#!/usr/bin/env python
import sys, random  
from socket import *
import threading
import time
serverPort = 12000
serverSocket = socket(AF_INET, SOCK_DGRAM)
serverSocket.bind(('', serverPort))

#用户登录
def login(userlist,message):
    usernumber = len(userlist)
    temp = message
    userlist.append(temp)

#定义房间类
class room:
    blackclient = 'noone'
    blackaddress =  'noone'  #记录黑色方地址
    whiteclient = 'noone'
    whiteaddress = 'noone'#记录白色方地址
    bystander =[] #旁观者的地址列表
    step = [] #步骤记录列表
    def _init_ (self):#初始化
        self.blackclient = 'noone'
        self.blackaddress =  'noone' 
        self.whiteclient = 'noone'
        self.whiteaddress = 'noone'
        self.bystander = []
        self.step = []
    def reset(self):
    	self.blackclient = 'noone'
    	self.blackaddress =  'noone' 
    	self.whiteclient = 'noone'
    	self.whiteaddress = 'noone'
    	self.bystander = []
    	self.step = []
    def set_blackclient(self,blackclient):
        self.blackclient = blackclient
    def set_blackclient(self,blackclient,blackaddress):
        self.blackclient = blackclient
        self.blackaddress = blackaddress
    def set_whiteclient(self,whiteclient):
        self.whiteclient = whiteclient
    def set_whiteclient(self,whiteclient,whiteaddress):
        self.whiteclient = whiteclient
        self.whiteaddress = whiteaddress
    def set_bystander(self,bystanderaddress):
        self.bystander.append(bystanderaddress)
    def set_step(self,step):
        self.step.append(step)

def print_user(userlist):
    usernumber = len(userlist)
    temp = "usernumber:" + str(usernumber)
    print(temp)
    for i in range(usernumber):
        temp = userlist[i]
        print (temp)

def send_room(room0,room1,room2,room3,room4,room5,room6,room7,room8,room9,clientAddress):
    modifimessage = "room0" + str(room0.blackclient) + str(room0.whiteclient)+ "room1" + str(room1.blackclient) + str(room1.whiteclient) + "room2" + str(room2.blackclient) + str(room2.whiteclient) + "room3" + str(room3.blackclient) + str(room3.whiteclient) + "room4" + str(room4.blackclient) + str(room4.whiteclient) + "room5" + str(room5.blackclient) + str(room5.whiteclient) + "room6" + str(room6.blackclient) + str(room6.whiteclient) + "room7" + str(room7.blackclient) + str(room7.whiteclient) + "room8" + str(room8.blackclient) + str(room8.whiteclient) + "room9" + str(room9.blackclient) + str(room9.whiteclient)#一个房间15位
    serverSocket.sendto(('%s\r' % modifimessage).encode(), clientAddress)

def send_user(userlist,clientAddress):
    modifimessage = ""
    usernumber = len(userlist)
    for i in range (0,usernumber):
        modifimessage = modifimessage + "user" + str(i)+ str(userlist[i])
    serverSocket.sendto(('%s\r' % modifimessage).encode(), clientAddress)

def join_room(room0,room1,room2,room3,room4,room5,room6,room7,room8,room9,roomn,username,clientAddress):
    if roomn == '0':
        if room0.blackclient == 'noone':
            room0.set_blackclient(username,clientAddress)
            serverSocket.sendto(("waitb").encode(), clientAddress)
        elif room0.whiteclient == 'noone':
            room0.set_whiteclient(username,clientAddress)
            serverSocket.sendto(("black").encode(), room0.blackaddress)
            serverSocket.sendto(("white").encode(), clientAddress)
        else:
            room0.set_bystander(clientAddress)
            serverSocket.sendto(("stand").encode(), clientAddress)
    elif roomn == '1':
        if room1.blackclient == 'noone':
            room1.set_blackclient(username,clientAddress)
            serverSocket.sendto(("waitb").encode(), clientAddress)
        elif room1.whiteclient == 'noone':
            room1.set_whiteclient(username,clientAddress)
            serverSocket.sendto(("black").encode(), room1.blackaddress)
            serverSocket.sendto(("white").encode(), clientAddress)
        else:
            room1.set_bystander(clientAddress)
            serverSocket.sendto(("stand").encode(), clientAddress)
    elif roomn == '2':
        if room2.blackclient == 'noone':
            room2.set_blackclient(username,clientAddress)
            serverSocket.sendto(("waitb").encode(), clientAddress)
        elif room2.whiteclient == 'noone':
            room2.set_whiteclient(username,clientAddress)
            serverSocket.sendto(("black").encode(), room2.blackaddress)
            serverSocket.sendto(("white").encode(), clientAddress)
        else:
            room2.set_bystander(clientAddress)
            serverSocket.sendto(("stand").encode(), clientAddress)
    elif roomn == '3':
        if room3.blackclient == 'noone':
            room3.set_blackclient(username,clientAddress)
            serverSocket.sendto(("waitb").encode(), clientAddress)
        elif room3.whiteclient == 'noone':
            room3.set_whiteclient(username,clientAddress)
            serverSocket.sendto(("black").encode(), room3.blackaddress)
            serverSocket.sendto(("white").encode(), clientAddress)
        else:
            room3.set_bystander(clientAddress)
            serverSocket.sendto(("stand").encode(), clientAddress)
    elif roomn == '4':
        if room4.blackclient == 'noone':
            room4.set_blackclient(username,clientAddress)
            serverSocket.sendto(("waitb").encode(), clientAddress)
        elif room4.whiteclient == 'noone':
            room4.set_whiteclient(username,clientAddress)
            serverSocket.sendto(("black").encode(), room4.blackaddress)
            serverSocket.sendto(("white").encode(), clientAddress)
        else:
            room4.set_bystander(clientAddress)
            serverSocket.sendto(("stand").encode(), clientAddress)
    elif roomn == '5':
        if room5.blackclient == 'noone':
            room5.set_blackclient(username,clientAddress)
            serverSocket.sendto(("waitb").encode(), clientAddress)
        elif room5.whiteclient == 'noone':
            room5.set_whiteclient(username,clientAddress)
            serverSocket.sendto(("black").encode(), room5.blackaddress)
            serverSocket.sendto(("white").encode(), clientAddress)
        else:
            room5.set_bystander(clientAddress)
            serverSocket.sendto(("stand").encode(), clientAddress)
    elif roomn == '6':
        if room6.blackclient == 'noone':
            room6.set_blackclient(username,clientAddress)
            serverSocket.sendto(("waitb").encode(), clientAddress)
        elif room6.whiteclient == 'noone':
            room6.set_whiteclient(username,clientAddress)
            serverSocket.sendto(("black").encode(), room6.blackaddress)
            serverSocket.sendto(("white").encode(), clientAddress)
        else:
            room6.set_bystander(clientAddress)
            serverSocket.sendto(("stand").encode(), clientAddress)
    elif roomn == '7':
        if room7.blackclient == 'noone':
            room7.set_blackclient(username,clientAddress)
            serverSocket.sendto(("waitb").encode(), clientAddress)
        elif room7.whiteclient == 'noone':
            room7.set_whiteclient(username,clientAddress)
            serverSocket.sendto(("black").encode(), room7.blackaddress)
            serverSocket.sendto(("white").encode(), clientAddress)
        else:
            room7.set_bystander(clientAddress)
            serverSocket.sendto(("stand").encode(), clientAddress)
    elif roomn == '8':
        if room8.blackclient == 'noone':
            room8.set_blackclient(username,clientAddress)
            serverSocket.sendto(("waitb").encode(), clientAddress)
        elif room8.whiteclient == 'noone':
            room8.set_whiteclient(username,clientAddress)
            serverSocket.sendto(("black").encode(), room8.blackaddress)
            serverSocket.sendto(("white").encode(), clientAddress)
        else:
            room8.set_bystander(clientAddress)
            serverSocket.sendto(("stand").encode(), clientAddress)
    elif roomn == 9:
        if room9.blackclient == 'noone':
            room9.set_blackclient(username,clientAddress)
            serverSocket.sendto(("waitb").encode(), clientAddress)
        elif room9.whiteclient == 'noone':
            room9.set_whiteclient(username,clientAddress)
            serverSocket.sendto(("black").encode(), room9.blackaddress)
            serverSocket.sendto(("white").encode(), clientAddress)
        else:
            room9.set_bystander(clientAddress)
            serverSocket.sendto(("stand").encode(), clientAddress)
    
def move(room0,room1,room2,room3,room4,room5,room6,room7,room8,room9,clientAddress,message):
    if clientAddress == room0.blackaddress:
        room0.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room0.whiteaddress)
    elif clientAddress == room0.whiteaddress:
        room0.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room0.blackaddress)
    elif clientAddress == room1.blackaddress:
        room1.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room1.whiteaddress)
    elif clientAddress == room1.whiteaddress:
        room1.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room1.blackaddress)
    elif clientAddress == room2.blackaddress:
        room2.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room2.whiteaddress)
    elif clientAddress == room2.whiteaddress:
        room2.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room2.blackaddress)
    elif clientAddress == room3.blackaddress:
        room3.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room3.whiteaddress)
    elif clientAddress == room3.whiteaddress:
        room3.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room3.blackaddress)
    elif clientAddress == room4.blackaddress:
        room4.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room4.whiteaddress)
    elif clientAddress == room4.whiteaddress:
        room4.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room4.blackaddress)
    elif clientAddress == room5.blackaddress:
        room5.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room5.whiteaddress)
    elif clientAddress == room5.whiteaddress:
        room5.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room5.blackaddress)
    elif clientAddress == room6.blackaddress:
        room6.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room6.whiteaddress)
    elif clientAddress == room6.whiteaddress:
        room6.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room6.blackaddress)
    elif clientAddress == room7.blackaddress:
        room7.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room7.whiteaddress)
    elif clientAddress == room7.whiteaddress:
        room7.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room7.blackaddress)
    elif clientAddress == room8.blackaddress:
        room8.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room8.whiteaddress)
    elif clientAddress == room8.whiteaddress:
        room8.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room8.blackaddress)
    elif clientAddress == room9.blackaddress:
        room9.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room9.whiteaddress)
    elif clientAddress == room9.whiteaddress:
        room9.set_step(message)
        serverSocket.sendto(('%s\r' % message).encode(), room9.blackaddress)

def print_room(room0,room1,room2,room3,room4,room5,room6,room7,room8,room9):
	print("room0:黑色方：" + room0.blackclient + "    白色方：" + room0.whiteclient)
	print("room1:黑色方：" + room1.blackclient + "    白色方：" + room1.whiteclient)
	print("room2:黑色方：" + room2.blackclient + "    白色方：" + room2.whiteclient)
	print("room3:黑色方：" + room3.blackclient + "    白色方：" + room3.whiteclient)
	print("room4:黑色方：" + room4.blackclient + "    白色方：" + room4.whiteclient)
	print("room5:黑色方：" + room5.blackclient + "    白色方：" + room5.whiteclient)
	print("room6:黑色方：" + room6.blackclient + "    白色方：" + room6.whiteclient)
	print("room7:黑色方：" + room7.blackclient + "    白色方：" + room7.whiteclient)
	print("room8:黑色方：" + room8.blackclient + "    白色方：" + room8.whiteclient)
	print("room9:黑色方：" + room9.blackclient + "    白色方：" + room9.whiteclient)

def close_room(room0,room1,room2,room3,room4,room5,room6,room7,room8,room9,roomn):
	if roomn == "room0":
		room0.reset()
		print("关闭成功！")
	elif roomn == "room1":
		room1.reset()
		print("关闭成功！")
	elif roomn == "room2":
		room2.reset()
		print("关闭成功！")
	elif roomn == "room3":
		room3.reset()
		print("关闭成功！")
	elif roomn == "room4":
		room4.reset()
		print("关闭成功！")
	elif roomn == "room5":
		room5.reset()
		print("关闭成功！")
	elif roomn == "room6":
		room6.reset()
		print("关闭成功！")
	elif roomn == "room7":
		room7.reset()
		print("关闭成功！")
	elif roomn == "room8":
		room8.reset()
		print("关闭成功！")
	elif roomn == "room9":
		room9.reset()
		print("关闭成功！")
	else:
		print("关闭失败或输入房间不存在，查看所有房间请输入：/g")

def kickout(username,userlist):	
	usernumber = len(userlist)
	flag = 0
	for i in range(usernumber):
		print(str(userlist[i]))
		print(str(username))
		if str(username) == str(userlist[i]):
			del userlist[i]
			print ("踢出成功！")
			flag = 1
	if flag == 0:
		print("踢出失败或该用户不存在，查看所有用户请输入：/l")



class GameThread (threading.Thread):   #继承父类threading.Thread
    def __init__(self, threadID, name, delay, userlist,room0,room1,room2,room3,room4,room5,room6,room7,room8,room9):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
        self.delay = delay
        self.userlist = userlist
        self.room0 = room0
        self.room1 = room1
        self.room2 = room2
        self.room3 = room3
        self.room4 = room4
        self.room5 = room5
        self.room6 = room6
        self.room7 = room7
        self.room8 = room8
        self.room9 = room9
    def run(self):
        print ("Starting " + self.name)
        Game(self.name, self.delay, self.userlist, self.room0, self.room1, self.room2, self.room3, self.room4, self.room5, self.room6, self.room7, self.room8, self.room9)
        print ("Exiting " + self.name)

class OperateThread (threading.Thread):   #继承父类threading.Thread
    def __init__(self, threadID, name, delay, userlist,room0,room1,room2,room3,room4,room5,room6,room7,room8,room9):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.name = name
        self.delay = delay
        self.userlist = userlist
        self.room0 = room0
        self.room1 = room1
        self.room2 = room2
        self.room3 = room3
        self.room4 = room4
        self.room5 = room5
        self.room6 = room6
        self.room7 = room7
        self.room8 = room8
        self.room9 = room9
    def run(self):
        print ("Starting " + self.name)
        Operate(self.name, self.delay, self.userlist, self.room0, self.room1, self.room2, self.room3, self.room4, self.room5, self.room6, self.room7, self.room8, self.room9)
        print ("Exiting " + self.name)

def Operate(threadName,delay,userlist,room0,room1,room2,room3,room4,room5,room6,room7,room8,room9):
	print("/h 获取帮助信息")
	while True:
		time.sleep(delay)
		operateinfo = input("")
		if operateinfo[0:2] == "/h":
			print("/h 获取帮助信息")
			print("/l 列出所有玩家 ")
			print("/g 列出比赛棋局")
            #print("/w 观看某一棋局，注：获取该棋局的每一步")
			print("/k 将某玩家踢出游戏,例如：/kXXXXX 即踢出XXXXX")
			print("/c 关闭某一棋局,例如：/croom0 即关闭room0")
		elif operateinfo[0:2] == "/l":
			print_user(userlist)
		elif operateinfo[0:2] == "/g":
			print_room(room0,room1,room2,room3,room4,room5,room6,room7,room8,room9)
		elif operateinfo[0:2] == "/k":
			username = operateinfo[2:]
			kickout(username,userlist)
		elif operateinfo[0:2] == "/c":
			roomn = operateinfo[2:]
			close_room(room0,room1,room2,room3,room4,room5,room6,room7,room8,room9,roomn)
			

def Game(threadName, delay, userlist,room0,room1,room2,room3,room4,room5,room6,room7,room8,room9):
	print ("这个服务器已经在运行了！")
	while True:
		time.sleep(delay)
		message, clientAddress = serverSocket.recvfrom(2048)
		temp = (message.decode('utf-8'))
		if temp [0:5] == "login":
			login(userlist,temp[5:])
		elif temp [0:5] == "getro":
			send_room(room0,room1,room2,room3,room4,room5,room6,room7,room8,room9,clientAddress)
		elif temp [0:5] == "getus":
			send_user(userlist,clientAddress)
		elif temp [0:5] == "joinr":
			roomn = temp[8]
			username = temp[9:14]
			join_room(room0,room1,room2,room3,room4,room5,room6,room7,room8,room9,roomn,username,clientAddress)
		else:
			temp = int(temp)
			move(room0,room1,room2,room3,room4,room5,room6,room7,room8,room9,clientAddress,temp)

userlist = []#用户名列表初始化为空
#创建10个房间
room0 = room()
room1 = room()
room2 = room()
room3 = room()
room4 = room()
room5 = room()
room6 = room()
room7 = room()
room8 = room()
room9 = room()

thread1 = GameThread(1, "Game-Thread", 1, userlist,room0,room1,room2,room3,room4,room5,room6,room7,room8,room9)
thread2 = OperateThread(2, "Operate-Thread", 1, userlist,room0,room1,room2,room3,room4,room5,room6,room7,room8,room9)
thread1.start()
thread2.start()
